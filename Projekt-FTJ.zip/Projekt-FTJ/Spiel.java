
/**
 * Beschreiben Sie hier die Klasse Spiel.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Spiel extends Gitter
{
    Gitter G1 = new Gitter(); 
    int i = 10;
    Kreis Spieler;
    public Spiel()
    {
        Spieler = new Kreis();
        Spieler. PositionSetzen(22, 22);
        Spieler.FarbeSetzen("rot");
        i = 0;

    }

    void TasteGedrückt (char taste)
    {

        if (taste == 'w')
        {
            Spieler.Verschieben( 0,  -40);
        }
        if (taste == 'a')
        {
            Spieler.Verschieben( -40,  0);
        }
        if (taste == 's')
        {
            Spieler.Verschieben( 0,  40);
        }
        if (taste == 'd')
        {
            Spieler.Verschieben( 40,  0);
        }
        i++;
    }

    void up()
    {
        if (Spieler.x > 20   )
        {
            Spieler.Verschieben( 0,  -40);
        }
    }

    void down()
    {
        if (Spieler.x < 380)
        {
            Spieler.Verschieben( 0,  40);    
        }
    }

    void left()
    {
        Spieler.Verschieben( -40,  0);   
    }

    void right()
    {
        Spieler.Verschieben( 40,  0);   
    }
}