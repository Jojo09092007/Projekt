
/**
 * Das Haus, das renoviert werden soll, mit der Umgebung.
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Buehne extends Ereignisbehandlung
{
    Rechteck Horizontal1;
    Rechteck Horizontal2;
    Rechteck Horizontal3;
    Rechteck Horizontal4;
    Rechteck Horizontal5;
    Rechteck Horizontal6;
    Rechteck Horizontal7;
    Rechteck Horizontal8;
    Rechteck Horizontal9;
    Rechteck Horizontal10;
    Rechteck Horizontal11;

    Rechteck Vertikal1;
    Rechteck Vertikal2;
    Rechteck Vertikal3;
    Rechteck Vertikal4;
    Rechteck Vertikal5;
    Rechteck Vertikal6;
    Rechteck Vertikal7;
    Rechteck Vertikal8;
    Rechteck Vertikal9;
    Rechteck Vertikal10;
    Rechteck Vertikal11;

    Kreis Spieler;

    AudioPlayer player;
    int i;

    /**
     * Konstruktor fuer Objekte der Klasse Buehne
     */
    Buehne()
    {
        i = 0;
        player = new AudioPlayer();
        player.playAudio("test.mp3");

        Spieler = new Kreis();
        Spieler. PositionSetzen(22, 22);
        Spieler.FarbeSetzen("rot");

        
        Horizontal1 = new Rechteck();
        Horizontal1.PositionSetzen(0, 0);
        Horizontal1.GroesseSetzen(5, 400);
        Horizontal1.FarbeSetzen("schwarz");

        Horizontal2 = new Rechteck();
        Horizontal2.PositionSetzen(40, 0);
        Horizontal2.GroesseSetzen(5, 400);
        Horizontal2.FarbeSetzen("schwarz");

        Horizontal3 = new Rechteck();
        Horizontal3.PositionSetzen(80, 0);
        Horizontal3.GroesseSetzen(5, 400);
        Horizontal3.FarbeSetzen("schwarz");

        Horizontal4 = new Rechteck();
        Horizontal4.PositionSetzen(120, 0);
        Horizontal4.GroesseSetzen(5, 400);
        Horizontal4.FarbeSetzen("schwarz");

        Horizontal5 = new Rechteck();
        Horizontal5.PositionSetzen(160, 0);
        Horizontal5.GroesseSetzen(5, 400);
        Horizontal5.FarbeSetzen("schwarz");

        Horizontal6 = new Rechteck();
        Horizontal6.PositionSetzen(200, 0);
        Horizontal6.GroesseSetzen(5, 400);
        Horizontal6.FarbeSetzen("schwarz");

        Horizontal7 = new Rechteck();
        Horizontal7.PositionSetzen(240, 0);
        Horizontal7.GroesseSetzen(5, 400);
        Horizontal7.FarbeSetzen("schwarz");

        Horizontal8 = new Rechteck();
        Horizontal8.PositionSetzen(280, 0);
        Horizontal8.GroesseSetzen(5, 400);
        Horizontal8.FarbeSetzen("schwarz");

        Horizontal9 = new Rechteck();
        Horizontal9.PositionSetzen(320, 0);
        Horizontal9.GroesseSetzen(5, 400);
        Horizontal9.FarbeSetzen("schwarz");

        Horizontal10 = new Rechteck();
        Horizontal10.PositionSetzen(360, 0);
        Horizontal10.GroesseSetzen(5,400);
        Horizontal10.FarbeSetzen("schwarz");

        Horizontal11 = new Rechteck();
        Horizontal11.PositionSetzen(400, 0);
        Horizontal11.GroesseSetzen(5,405);
        Horizontal11.FarbeSetzen("schwarz");

        Vertikal1 = new Rechteck();
        Vertikal1.PositionSetzen(0, 0);
        Vertikal1.GroesseSetzen(400,5);
        Vertikal1.FarbeSetzen("schwarz");

        Vertikal2 = new Rechteck();
        Vertikal2.PositionSetzen(0, 40);
        Vertikal2.GroesseSetzen(400,5);
        Vertikal2.FarbeSetzen("schwarz");

        Vertikal3 = new Rechteck();
        Vertikal3.PositionSetzen(0, 80);
        Vertikal3.GroesseSetzen(400,5);
        Vertikal3.FarbeSetzen("schwarz");

        Vertikal4 = new Rechteck();
        Vertikal4.PositionSetzen(0, 120);
        Vertikal4.GroesseSetzen(400,5);
        Vertikal4.FarbeSetzen("schwarz");

        Vertikal5 = new Rechteck();
        Vertikal5.PositionSetzen(0, 160);
        Vertikal5.GroesseSetzen(400,5);
        Vertikal5.FarbeSetzen("schwarz");

        Vertikal6 = new Rechteck();
        Vertikal6.PositionSetzen(0, 200);
        Vertikal6.GroesseSetzen(400,5);
        Vertikal6.FarbeSetzen("schwarz");

        Vertikal7 = new Rechteck();
        Vertikal7.PositionSetzen(0, 240);
        Vertikal7.GroesseSetzen(400,5);
        Vertikal7.FarbeSetzen("schwarz");

        Vertikal8 = new Rechteck();
        Vertikal8.PositionSetzen(0, 280);
        Vertikal8.GroesseSetzen(400,5);
        Vertikal8.FarbeSetzen("schwarz");

        Vertikal9 = new Rechteck();
        Vertikal9.PositionSetzen(0, 320);
        Vertikal9.GroesseSetzen(400,5);
        Vertikal9.FarbeSetzen("schwarz");

        Vertikal10 = new Rechteck();
        Vertikal10.PositionSetzen(0, 360);
        Vertikal10.GroesseSetzen(400,5);
        Vertikal10.FarbeSetzen("schwarz");

        Vertikal11 = new Rechteck();
        Vertikal11.PositionSetzen(0, 400);
        Vertikal11.GroesseSetzen(405,5);
        Vertikal11.FarbeSetzen("schwarz");

        
    }
    void up()
    {

        Spieler.Verschieben( 0,  -40);
    }

    void down()
    {
        Spieler.Verschieben( 0,  40);    
    }

    void left()
    {
        Spieler.Verschieben( -40,  0);   
    }

    void right()
    {
        Spieler.Verschieben( 40,  0);   
    }

    /**
     * Das Dach muss um 100 nach rechts und 50 nach unten.
     */
    void DachVerschieben()
    {
        //Code ergaenzen!
    }

    /**
     * Das Dachfenster muss in den Vordergrund gerueckt werden.
     */
    void DachfensterNachVorneHolen()
    {
        //Code ergaenzen!
    }

    /**
     * Das Haus soll weiss gestrichen werden.
     */
    void HausTuenchen()
    {
        //Code ergaenzen!
    }

    /**
     * Die Tuer muss um 20 nach links.
     */
    void TuerNachLinks()
    {
        //Code ergaenzen!
    }

    /**
     * Das Fenster muss um 15 Grad gedreht werden.
     */
    void FensterDrehen()
    {
        //Code ergaenzen!
    }

    /**
     * Der Boden muss begruent werden.
     */
    void BodenBegruenen()
    {
        //Code ergaenzen!
    }

    /**
     * Der Himmel muss blau werden.
     */
    void HimmelFaerben()
    {
        //Code ergaenzen!
    }

    /**
     * Die Sonne muss gelb und passender positioniert werden.
     */
    void SonneKorrigieren()
    {
        //erst bei Aufgabe c) bearbeiten!
        //sonne.FarbeSetzen("gelb");
        //sonne.PositionSetzen(700,80);
    }

    /**
     * Taktsteuerung des Films
     */
    @Override void TaktImpulsAusfuehren()
    {
        switch(i)
        {
            case 0: 
                DachVerschieben();
                break;
            case 1: 
                DachfensterNachVorneHolen();
                break;
            case 2: 
                HausTuenchen();
                break;
            case 3:
                TuerNachLinks();
                break;
            case 4: 
                FensterDrehen();
                break;
            case 5: 
                BodenBegruenen();
                break;
            case 6: 
                HimmelFaerben();
                break;
            case 7:
                SonneKorrigieren();
        }
        i = i + 1;
    }

}
