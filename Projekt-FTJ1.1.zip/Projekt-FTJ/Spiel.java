
/**
 * Beschreiben Sie hier die Klasse Spiel.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Spiel extends Ereignisbehandlung
{
    Gitter G1 = new Gitter(); 
    int i = 10;
    Kreis Spieler;
    Soundboard s1 = new Soundboard();

    public Spiel()
    {
        Spieler = new Kreis();
        Spieler. PositionSetzen(22, 22);
        Spieler.FarbeSetzen("rot");
        i = 0;
        s1.Boom();

    }

    
    @Override char TasteGedrueckt(char taste)
    {
        
        System.out.println(taste);

        switch (taste)
        {
            case 'w':
                
                if (Spieler.y > 50   )
                {
                    Spieler.Verschieben( 0,  -40);
                }
                
                break;
            case 's':
                if (Spieler.y < 380)
                {
                    Spieler.Verschieben( 0,  40);    
                }
                break;
            case 'a':
                if (Spieler.x > 50)
                {
                    Spieler.Verschieben( -40,  0);   
                }
                break;
            case 'd':
                if (Spieler.x < 380)
                {
                    Spieler.Verschieben( 40,  0);   
                }
                break;
        }
        return taste;
    }
    
}