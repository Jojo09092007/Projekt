
/**
 * Das Haus, das renoviert werden soll, mit der Umgebung.
 * 
 * @author Klaus Reinold
 * @version 1.0
 */
class Gitter 
{
    
    
    Rechteck Horizontal1 = new Rechteck();
    Rechteck Horizontal2= new Rechteck();
    Rechteck Horizontal3= new Rechteck();
    Rechteck Horizontal4= new Rechteck();
    Rechteck Horizontal5= new Rechteck();
    Rechteck Horizontal6= new Rechteck();
    Rechteck Horizontal7= new Rechteck();
    Rechteck Horizontal8= new Rechteck();
    Rechteck Horizontal9= new Rechteck();
    Rechteck Horizontal10= new Rechteck();
    Rechteck Horizontal11= new Rechteck();

    Rechteck Vertikal1= new Rechteck();
    Rechteck Vertikal2= new Rechteck();
    Rechteck Vertikal3= new Rechteck();
    Rechteck Vertikal4= new Rechteck();
    Rechteck Vertikal5= new Rechteck();
    Rechteck Vertikal6= new Rechteck();
    Rechteck Vertikal7= new Rechteck();
    Rechteck Vertikal8= new Rechteck();
    Rechteck Vertikal9= new Rechteck();
    Rechteck Vertikal10= new Rechteck();
    Rechteck Vertikal11= new Rechteck();

    

    
    int i;

    /**
     * Konstruktor fuer Objekte der Klasse Buehne
     */
    Gitter()
    {
        i = 0;
        
        

        Horizontal1.PositionSetzen(0, 0);
        Horizontal1.GroesseSetzen(5, 400);
        Horizontal1.FarbeSetzen("schwarz");
        
        
        Horizontal2.PositionSetzen(40, 0);
        Horizontal2.GroesseSetzen(5, 400);
        Horizontal2.FarbeSetzen("schwarz");

     
        Horizontal3.PositionSetzen(80, 0);
        Horizontal3.GroesseSetzen(5, 400);
        Horizontal3.FarbeSetzen("schwarz");

        Horizontal4.PositionSetzen(120, 0);
        Horizontal4.GroesseSetzen(5, 400);
        Horizontal4.FarbeSetzen("schwarz");

        Horizontal5.PositionSetzen(160, 0);
        Horizontal5.GroesseSetzen(5, 400);
        Horizontal5.FarbeSetzen("schwarz");

        Horizontal6.PositionSetzen(200, 0);
        Horizontal6.GroesseSetzen(5, 400);
        Horizontal6.FarbeSetzen("schwarz");

        Horizontal7.PositionSetzen(240, 0);
        Horizontal7.GroesseSetzen(5, 400);
        Horizontal7.FarbeSetzen("schwarz");

        Horizontal8.PositionSetzen(280, 0);
        Horizontal8.GroesseSetzen(5, 400);
        Horizontal8.FarbeSetzen("schwarz");

        Horizontal9 = new Rechteck();
        Horizontal9.PositionSetzen(320, 0);
        Horizontal9.GroesseSetzen(5, 400);
        Horizontal9.FarbeSetzen("schwarz");

        Horizontal10.PositionSetzen(360, 0);
        Horizontal10.GroesseSetzen(5,400);
        Horizontal10.FarbeSetzen("schwarz");

        Horizontal11.PositionSetzen(400, 0);
        Horizontal11.GroesseSetzen(5,405);
        Horizontal11.FarbeSetzen("schwarz");

        Vertikal1.PositionSetzen(0, 0);
        Vertikal1.GroesseSetzen(400,5);
        Vertikal1.FarbeSetzen("schwarz");

        Vertikal2.PositionSetzen(0, 40);
        Vertikal2.GroesseSetzen(400,5);
        Vertikal2.FarbeSetzen("schwarz");

        Vertikal3.PositionSetzen(0, 80);
        Vertikal3.GroesseSetzen(400,5);
        Vertikal3.FarbeSetzen("schwarz");

        Vertikal4.PositionSetzen(0, 120);
        Vertikal4.GroesseSetzen(400,5);
        Vertikal4.FarbeSetzen("schwarz");

        Vertikal5.PositionSetzen(0, 160);
        Vertikal5.GroesseSetzen(400,5);
        Vertikal5.FarbeSetzen("schwarz");

        Vertikal6.PositionSetzen(0, 200);
        Vertikal6.GroesseSetzen(400,5);
        Vertikal6.FarbeSetzen("schwarz");

        Vertikal7.PositionSetzen(0, 240);
        Vertikal7.GroesseSetzen(400,5);
        Vertikal7.FarbeSetzen("schwarz");

        Vertikal8.PositionSetzen(0, 280);
        Vertikal8.GroesseSetzen(400,5);
        Vertikal8.FarbeSetzen("schwarz");

        Vertikal9.PositionSetzen(0, 320);
        Vertikal9.GroesseSetzen(400,5);
        Vertikal9.FarbeSetzen("schwarz");

        Vertikal10.PositionSetzen(0, 360);
        Vertikal10.GroesseSetzen(400,5);
        Vertikal10.FarbeSetzen("schwarz");

        Vertikal11.PositionSetzen(0, 400);
        Vertikal11.GroesseSetzen(405,5);
        Vertikal11.FarbeSetzen("schwarz");

                

    }
    
    /**
     * Das Dach muss um 100 nach rechts und 50 nach unten.
     */
    void DachVerschieben()
    {
        //Code ergaenzen!
    }

    /**
     * Das Dachfenster muss in den Vordergrund gerueckt werden.
     */
    void DachfensterNachVorneHolen()
    {
        //Code ergaenzen!
    }

    /**
     * Das Haus soll weiss gestrichen werden.
     */
    void HausTuenchen()
    {
        //Code ergaenzen!
    }

    /**
     * Die Tuer muss um 20 nach links.
     */
    void TuerNachLinks()
    {
        //Code ergaenzen!
    }

    /**
     * Das Fenster muss um 15 Grad gedreht werden.
     */
    void FensterDrehen()
    {
        //Code ergaenzen!
    }

    /**
     * Der Boden muss begruent werden.
     */
    void BodenBegruenen()
    {
        //Code ergaenzen!
    }

    /**
     * Der Himmel muss blau werden.
     */
    void HimmelFaerben()
    {
        //Code ergaenzen!
    }

    /**
     * Die Sonne muss gelb und passender positioniert werden.
     */
    void SonneKorrigieren()
    {
        //erst bei Aufgabe c) bearbeiten!
        //sonne.FarbeSetzen("gelb");
        //sonne.PositionSetzen(700,80);
    }

    

}
