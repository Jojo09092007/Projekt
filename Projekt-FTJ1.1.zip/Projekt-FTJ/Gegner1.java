import java.util.*;
/**
 * Beschreiben Sie hier die Klasse Gegner1.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Gegner1
{
    // Attribute
    Kreis Body = new Kreis();
    int xGegner1;
    int yGegner1;
    // Konstruktor(en)    
    public Gegner1()
    {
        xGegner1 = new Random().nextInt(10) ;
        yGegner1 = new Random().nextInt(10) ;
        Body = new Kreis();
        Body. PositionSetzen(xGegner1 *40 + 22, yGegner1 *40 + 22);
        Body.FarbeSetzen("rot");
    }

    // Methoden
    public void AutoGegner()
    {
        for(int c=0 ; c<15; c++)
        {
            xGegner1 = new Random().nextInt(10) ;
            yGegner1 = new Random().nextInt(10) ;
            Body = new Kreis();
            Body. PositionSetzen(xGegner1 *40 + 22, yGegner1 *40 + 22);
            Body.FarbeSetzen("rot");
        }
    }
}
