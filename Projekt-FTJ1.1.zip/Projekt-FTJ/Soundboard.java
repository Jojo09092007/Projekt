
/**
 * Beschreiben Sie hier die Klasse Soundboard.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Soundboard
{
    AudioPlayer player;   
    public Soundboard()
    {
     player = new AudioPlayer();
     
    }
    void Boom(){player.playAudio("Musik/Vine_Boom.wav");}
    void Boing(){player.playAudio("Musik/Boing.wav");}
    void Fart(){player.playAudio("Musik/Fart.wav");}
    void GoofyFart(){player.playAudio("Musik/goofy_ahh.wav");}
    void GoofyLaugh(){player.playAudio("Musik/Goofy_Laugh.wav");}
    void Metal_Pipe(){player.playAudio("Musik/Metal_Pipe.wav");}
    void OOF(){player.playAudio("Musik/OOF.wav");}
    void Outro(){player.playAudio("Musik/Outro.wav");}
    void Rizz(){player.playAudio("Musik/RIZZ.wav");}
    void Whistle(){player.playAudio("Musik/whistle.wav");}
    void YAY(){player.playAudio("Musik/Yay_sound.wav");}
    void YEAY(){player.playAudio("Musik/YEAY.wav");}
    void Dead(){player.playAudio("Musik/You_DIED.wav");}
    
}
